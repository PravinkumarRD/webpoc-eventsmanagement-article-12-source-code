﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EventsManagementPortal.UI.Areas.WebPoCEmployees.Controllers
{
    public class HomeController : Controller
    {
        // GET: WebPoCEmployees/Home
        public ActionResult Index()
        {
            ViewBag.PageTitle = "Welcome To WebPoCHub Employees List!";
            ViewBag.SubTitle = "Core Employees List  Of WebPoCHub Global Teams!";
            return View();
        }
    }
}