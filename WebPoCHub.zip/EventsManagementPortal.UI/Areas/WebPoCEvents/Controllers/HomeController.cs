﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EventsManagementPortal.UI.Areas.WebPoCEvents.Controllers
{
    public class HomeController : Controller
    {
        // GET: WebPoCEvents/Home
        public ActionResult Index()
        {
            ViewBag.PageTitle = "Welcome To WebPoCHub Future Events List!";
            ViewBag.SubTitle = "Published by WebPoCHub Global Hr Team!";
            return View();
        }
    }
}